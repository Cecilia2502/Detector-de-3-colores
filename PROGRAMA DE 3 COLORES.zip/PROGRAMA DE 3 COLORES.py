import cv2
import numpy as np

img = cv2.imread("Circulo.jpg")

hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)

morado_bajos = np.array([130,100,20])
morado_altos = np.array([165,255,255])

verde_bajos = np.array([36,100,20])
verde_altos = np.array([70,255,255])

naranja_bajos = np.array([11,100,20])
naranja_altos = np.array([23,255,255])

mask_morado = cv2.inRange(hsv, morado_bajos, morado_altos)
mask_verde = cv2.inRange(hsv, verde_bajos, verde_altos)
mask_naranja = cv2.inRange(hsv, naranja_bajos, naranja_altos)

mask_union = cv2.bitwise_or(mask_morado, mask_verde)
mask_union = cv2.bitwise_or(mask_union, mask_naranja)


cv2.imshow("Original", img)
cv2.imshow("Verde+morado+Naranja", mask_union)
print("PULSA CUALQUIER TECLA PARA CERRAR LAS VENTANAS")
cv2.waitKey(0)
cv2.destroyAllWindows()
